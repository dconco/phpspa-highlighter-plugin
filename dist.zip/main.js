/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/acodePlugin.ts":
/*!****************************!*\
  !*** ./src/acodePlugin.ts ***!
  \****************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const alert = acode.require("alert");
const fileList = acode.require("fileList");
const editorManager = acode.require("editorManager");
const phpSpaMode_1 = __webpack_require__(/*! ./phpSpaMode */ "./src/phpSpaMode.ts");
class AcodePlugin {
    constructor() {
        this.phpSpaMode = null;
        this.originalPhpMode = null;
    }
    init() {
        return __awaiter(this, void 0, void 0, function* () {
            // Set up event listeners for file operations
            if (editorManager && typeof editorManager.on === 'function') {
                // Apply mode when switching between files
                editorManager.on('switch-file', () => this.applyModeToCurrentFile());
                // Apply mode when a file is loaded/opened
                editorManager.on('file-loaded', () => this.applyModeToCurrentFile());
                // Apply mode when a new file is created
                editorManager.on('new-file', () => this.applyModeToCurrentFile());
            }
            // Initialize the mode after a delay to ensure Ace is fully loaded
            // Apply mode to any already-open PHP files after initialization
            setTimeout(() => {
                this.initializePhpSpaMode();
                if (this.phpSpaMode) {
                    this.applyModeToOpenFiles();
                    this.applyModeToCurrentFile();
                }
            }, 500);
        });
    }
    applyModeToCurrentFile() {
        if (!editorManager || !editorManager.activeFile) {
            return;
        }
        const file = editorManager.activeFile;
        if (file.filename && /\.php$/i.test(file.filename) && file.session && this.phpSpaMode) {
            try {
                // Set our custom mode
                file.session.setMode('ace/mode/phpspa');
                // Force re-tokenization to apply the new mode immediately
                if (file.session.bgTokenizer) {
                    file.session.bgTokenizer.start(0);
                }
                // Verify the mode was applied
                const currentMode = file.session.getMode();
                if (currentMode && currentMode.$id) {
                    console.log(`PhpSPA Highlighter: Mode applied to ${file.filename}, current mode: ${currentMode.$id}`);
                }
                else {
                    console.warn(`PhpSPA Highlighter: Mode may not have been applied correctly to ${file.filename}`);
                }
            }
            catch (error) {
                console.error('PhpSPA Highlighter: Error applying mode to file:', error);
            }
        }
    }
    applyModeToOpenFiles() {
        if (!editorManager || !editorManager.files || !this.phpSpaMode) {
            return;
        }
        const files = editorManager.files;
        files.forEach((file) => {
            try {
                if (file.filename && /\.php$/i.test(file.filename) && file.session) {
                    file.session.setMode('ace/mode/phpspa');
                    if (file.session.bgTokenizer) {
                        file.session.bgTokenizer.start(0);
                    }
                }
            }
            catch (error) {
                console.error('PhpSPA Highlighter: Error applying mode to open file:', error);
            }
        });
    }
    initializePhpSpaMode() {
        // In Acode, Ace Editor can be accessed through different paths
        // Try multiple methods to get the ace object
        let ace = null;
        // Method 1: Check for window.ace (standard Ace Editor global)
        if (typeof window.ace !== 'undefined' && window.ace) {
            ace = window.ace;
            console.log('PhpSPA Highlighter: Found ace via window.ace');
        }
        // Method 2: Check for global acequire (Ace's module loader)
        if (!ace && typeof window.acequire !== 'undefined') {
            const acequire = window.acequire;
            ace = {
                require: acequire,
                define: acequire.define || function () {
                    console.warn('acequire.define not available');
                }
            };
            console.log('PhpSPA Highlighter: Found ace via global acequire');
        }
        // Method 3: Try to get ace from editorManager
        if (!ace && editorManager && editorManager.editor) {
            const editor = editorManager.editor;
            // Check if the editor has an ace property
            if (editor.ace) {
                ace = editor.ace;
                console.log('PhpSPA Highlighter: Found ace via editorManager.editor.ace');
            }
            // Check if editor.env exists (Ace Editor instance has env property)
            else if (editor.env && editor.env.editor) {
                ace = window.ace || {
                    require: window.acequire || function () { },
                    define: (window.acequire && window.acequire.define) || function () { }
                };
                console.log('PhpSPA Highlighter: Found ace via editor.env');
            }
        }
        if (!ace) {
            console.error('PhpSPA Highlighter: Ace Editor not found after trying all methods');
            console.error('Debugging information:');
            console.error('- typeof window.ace:', typeof window.ace);
            console.error('- typeof window.acequire:', typeof window.acequire);
            console.error('- typeof editorManager:', typeof editorManager);
            if (editorManager) {
                console.error('- typeof editorManager.editor:', typeof editorManager.editor);
                if (editorManager.editor) {
                    console.error('- typeof editorManager.editor.ace:', typeof editorManager.editor.ace);
                    console.error('- typeof editorManager.editor.env:', typeof editorManager.editor.env);
                }
            }
            console.error('Please report this issue with the above debugging information');
            return;
        }
        try {
            this.phpSpaMode = new phpSpaMode_1.PhpSpaMode(ace);
            // Register our custom mode with Ace
            this.phpSpaMode.register();
            console.log('PhpSPA Highlighter: Mode registered successfully');
        }
        catch (error) {
            console.error('PhpSPA Highlighter: Error initializing mode:', error);
            console.error('Error details:', error);
        }
    }
    destroy() {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            (_a = this.sideButton) === null || _a === void 0 ? void 0 : _a.hide();
            if (this.originalPhpMode && window.ace) {
                window.ace.define("ace/mode/php", ["require", "exports", "module"], (require, exports) => {
                    exports.Mode = this.originalPhpMode;
                });
            }
            this.phpSpaMode = null;
            this.originalPhpMode = null;
        });
    }
}
exports["default"] = AcodePlugin;


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const plugin = __webpack_require__(/*! ../plugin.json */ "./plugin.json");
const acodePlugin_1 = __importDefault(__webpack_require__(/*! ./acodePlugin */ "./src/acodePlugin.ts"));
if (window.acode) {
    const acodePlugin = new acodePlugin_1.default();
    acode.setPluginInit(plugin.id, (baseUrl_1, $page_1, _a) => __awaiter(void 0, [baseUrl_1, $page_1, _a], void 0, function* (baseUrl, $page, { cacheFileUrl, cacheFile }) {
        if (!baseUrl.endsWith("/")) {
            baseUrl += "/";
        }
        acodePlugin.baseUrl = baseUrl;
        yield acodePlugin.init();
    }));
    acode.setPluginUnmount(plugin.id, () => {
        acodePlugin.destroy();
    });
}


/***/ }),

/***/ "./src/phpSpaMode.ts":
/*!***************************!*\
  !*** ./src/phpSpaMode.ts ***!
  \***************************/
/***/ (function(__unused_webpack_module, exports) {


/**
 * PhpSPA Syntax Mode for Ace Editor
 * Extends PHP syntax highlighting to support embedded HTML, CSS, and JavaScript in heredoc/nowdoc blocks
 *
 * This implementation uses Ace's embedRules feature to properly embed language modes
 * for a seamless multi-language syntax highlighting experience.
 */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PhpSpaMode = void 0;
class PhpSpaMode {
    constructor(ace) {
        this.ace = ace;
    }
    createMode() {
        const ace = this.ace;
        // Load required ace modules with error handling
        let oop, PhpMode, PhpHighlightRules, HtmlHighlightRules, CssHighlightRules, JavaScriptHighlightRules;
        try {
            oop = ace.require("ace/lib/oop");
            if (!oop)
                throw new Error("Failed to load ace/lib/oop");
            const phpModule = ace.require("ace/mode/php");
            PhpMode = phpModule.Mode;
            if (!PhpMode)
                throw new Error("Failed to load PHP Mode");
            const phpHighlightModule = ace.require("ace/mode/php_highlight_rules");
            PhpHighlightRules = phpHighlightModule.PhpHighlightRules;
            if (!PhpHighlightRules)
                throw new Error("Failed to load PHP Highlight Rules");
            const htmlHighlightModule = ace.require("ace/mode/html_highlight_rules");
            HtmlHighlightRules = htmlHighlightModule.HtmlHighlightRules;
            if (!HtmlHighlightRules)
                throw new Error("Failed to load HTML Highlight Rules");
            const cssHighlightModule = ace.require("ace/mode/css_highlight_rules");
            CssHighlightRules = cssHighlightModule.CssHighlightRules;
            if (!CssHighlightRules)
                throw new Error("Failed to load CSS Highlight Rules");
            const jsHighlightModule = ace.require("ace/mode/javascript_highlight_rules");
            JavaScriptHighlightRules = jsHighlightModule.JavaScriptHighlightRules;
            if (!JavaScriptHighlightRules)
                throw new Error("Failed to load JavaScript Highlight Rules");
            console.log('PhpSPA Highlighter: All Ace modules loaded successfully');
        }
        catch (error) {
            console.error('PhpSPA Highlighter: Error loading Ace modules:', error);
            throw error;
        }
        // Create custom highlight rules that extend PHP rules
        const PhpSpaHighlightRules = function () {
            // Call parent constructor
            PhpHighlightRules.call(this);
            // Get instances of the embedded language highlight rules
            const htmlRules = new HtmlHighlightRules().getRules();
            const cssRules = new CssHighlightRules().getRules();
            const jsRules = new JavaScriptHighlightRules({ jsx: false }).getRules();
            // Define heredoc start patterns for HTML
            const htmlHeredocStart = {
                token: "string.heredoc.delimiter.php",
                regex: "<<<\\s*(HTML)\\s*$",
                next: "htmlHeredoc-start",
                push: true
            };
            const htmlNowdocStart = {
                token: "string.heredoc.delimiter.php",
                regex: "<<<\\s*'(HTML)'\\s*$",
                next: "htmlNowdoc-start",
                push: true
            };
            // Define heredoc start patterns for CSS
            const cssHeredocStart = {
                token: "string.heredoc.delimiter.php",
                regex: "<<<\\s*(CSS)\\s*$",
                next: "cssHeredoc-start",
                push: true
            };
            const cssNowdocStart = {
                token: "string.heredoc.delimiter.php",
                regex: "<<<\\s*'(CSS)'\\s*$",
                next: "cssNowdoc-start",
                push: true
            };
            // Define heredoc start patterns for JavaScript
            const jsHeredocStart = {
                token: "string.heredoc.delimiter.php",
                regex: "<<<\\s*(JS|JAVASCRIPT)\\s*$",
                next: "jsHeredoc-start",
                push: true
            };
            const jsNowdocStart = {
                token: "string.heredoc.delimiter.php",
                regex: "<<<\\s*'(JS|JAVASCRIPT)'\\s*$",
                next: "jsNowdoc-start",
                push: true
            };
            // Add heredoc start patterns to PHP start rules
            // These need to be at the beginning to have higher priority
            if (this.$rules.start) {
                this.$rules.start.unshift(htmlHeredocStart, htmlNowdocStart, cssHeredocStart, cssNowdocStart, jsHeredocStart, jsNowdocStart);
            }
            // Embed HTML highlighting rules for heredoc (with PHP variable interpolation)
            this.embedRules(htmlRules, "htmlHeredoc-", [
                {
                    token: "string.heredoc.delimiter.php",
                    regex: "^\\s*(HTML)\\s*;?\\s*$",
                    next: "pop"
                },
                {
                    token: "variable.other.php",
                    regex: "\\{\\$[a-zA-Z_\\x7f-\\xff][a-zA-Z0-9_\\x7f-\\xff]*\\}"
                }
            ]);
            // Embed HTML highlighting rules for nowdoc (no PHP variable interpolation)
            this.embedRules(htmlRules, "htmlNowdoc-", [
                {
                    token: "string.heredoc.delimiter.php",
                    regex: "^\\s*(HTML)\\s*;?\\s*$",
                    next: "pop"
                }
            ]);
            // Embed CSS highlighting rules for heredoc (with PHP variable interpolation)
            this.embedRules(cssRules, "cssHeredoc-", [
                {
                    token: "string.heredoc.delimiter.php",
                    regex: "^\\s*(CSS)\\s*;?\\s*$",
                    next: "pop"
                },
                {
                    token: "variable.other.php",
                    regex: "\\{\\$[a-zA-Z_\\x7f-\\xff][a-zA-Z0-9_\\x7f-\\xff]*\\}"
                }
            ]);
            // Embed CSS highlighting rules for nowdoc (no PHP variable interpolation)
            this.embedRules(cssRules, "cssNowdoc-", [
                {
                    token: "string.heredoc.delimiter.php",
                    regex: "^\\s*(CSS)\\s*;?\\s*$",
                    next: "pop"
                }
            ]);
            // Embed JavaScript highlighting rules for heredoc (with PHP variable interpolation)
            this.embedRules(jsRules, "jsHeredoc-", [
                {
                    token: "string.heredoc.delimiter.php",
                    regex: "^\\s*(JS|JAVASCRIPT)\\s*;?\\s*$",
                    next: "pop"
                },
                {
                    token: "variable.other.php",
                    regex: "\\{\\$[a-zA-Z_\\x7f-\\xff][a-zA-Z0-9_\\x7f-\\xff]*\\}"
                }
            ]);
            // Embed JavaScript highlighting rules for nowdoc (no PHP variable interpolation)
            this.embedRules(jsRules, "jsNowdoc-", [
                {
                    token: "string.heredoc.delimiter.php",
                    regex: "^\\s*(JS|JAVASCRIPT)\\s*;?\\s*$",
                    next: "pop"
                }
            ]);
            // Normalize all rules
            this.normalizeRules();
        };
        // Set up inheritance
        oop.inherits(PhpSpaHighlightRules, PhpHighlightRules);
        // Create the custom mode class
        const PhpSpaMode = function () {
            PhpMode.call(this);
            this.HighlightRules = PhpSpaHighlightRules;
            this.$id = "ace/mode/phpspa";
        };
        // Set up inheritance for the mode
        oop.inherits(PhpSpaMode, PhpMode);
        // Return the mode constructor
        return PhpSpaMode;
    }
    register() {
        const PhpSpaMode = this.createMode();
        // Register the custom mode with Ace
        this.ace.define("ace/mode/phpspa", ["require", "exports", "module"], (require, exports) => {
            exports.Mode = PhpSpaMode;
        });
        return PhpSpaMode;
    }
}
exports.PhpSpaMode = PhpSpaMode;


/***/ }),

/***/ "./plugin.json":
/*!*********************!*\
  !*** ./plugin.json ***!
  \*********************/
/***/ (function(module) {

module.exports = JSON.parse('{"id":"acode.plugin.phpspa","name":"PhpSPA Highlighter","main":"dist/main.js","version":"1.0.0","readme":"./README.md","icon":"icon.png","files":[],"license":"MIT","minVersionCode":290,"price":0,"author":{"name":"dconco","github":"dconco","email":"concodave@gmail.com","url":"https://dconco.github.io"}}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/main.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=main.js.map